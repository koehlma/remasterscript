sudo apt-get install -t unstable squashfs-tools
